
function populateTable(table, rows, cells, content) 
{
    if (!table) table = document.createElement('table');

    for (var i = 0; i < rows; ++i) {
        var row = document.createElement('tr');
        for (var j = 0; j < cells; ++j) {
            row.appendChild(document.createElement('td'));
            var x=document.createElement('input');
            x.id=i+','+j;
            row.cells[j].appendChild(x);
        }
        table.appendChild(row);
    }
   table.border=1;
    return table;
}
function create_table()
{
 
    var num_rows = document.getElementById('rows').value;
    var num_cols = document.getElementById('cols').value;
    var x = document.getElementById('wrapper');
    x.appendChild(populateTable(null, num_rows, num_cols, "text"));

}
function getvalues()
{
    var num_rows = document.getElementById('rows').value;
    var num_cols = document.getElementById('cols').value;
    alert(num_cols);
    alert(num_rows);
    var y='';
    var z='';
    for (var i = num_rows - 1; i >= 0; i--) {
        for (var j = num_cols - 1; j >= 0; j--) 
        { 
            y += document.getElementById(i+','+j).value+';';      
        }
    }
    y=y.split(';');
    document.getElementById('wrapper2').innerHTML+=y; 
}
    
function createTable()
{
    var num_rows = document.getElementById('rows').value;
    var num_cols = document.getElementById('cols').value;
    var theader = '<table border="2">\n';
    var tbody = '';

    for( var i=0; i<num_rows;i++)
    {
        tbody += '<tr>';
        for( var j=0; j<num_cols;j++)
        {
            tbody += '<td>';
            tbody += '<input type="text" name="table" id='+i+','+j+'></input>';
            tbody += '</td>'
        }
        tbody += '</tr>\n';
    }
    var tfooter = '</table>';
    document.getElementById('wrapper').innerHTML = theader + tbody + tfooter;
}